﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Infosys.CICD.SkyTapInterface
{
    class Logger
    {

        
       public static void writelog(Exception ex1)
       {
           
           using (StreamWriter writer = new StreamWriter(logfilePath, true))
{
    writer.WriteLine("Message :" + ex1.Message + "<br/>" + Environment.NewLine + "StackTrace :" + ex1.StackTrace +
       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
}

       }

       public static void writelog(string strLog)
       {

           using (StreamWriter writer = new StreamWriter(logfilePath, true))
           {
               writer.WriteLine(strLog +
                  "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
               writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
           }

       }

       public static string logfilePath { set; get; }
       
    }
    }

