﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.ServiceModel;
using System.IO.Compression;
using System.Xml;


namespace Infosys.CICD.SkyTapInterface
{
    class Program
    {
        static string strBuidNum = "10";
        static string strfolderPath;
        static string strfileName;
        static string strServiceURL;

        static void Main(string[] args)
        {
            Logger.logfilePath = System.Configuration.ConfigurationSettings.AppSettings["logPath"];
              strfolderPath = System.Configuration.ConfigurationSettings.AppSettings["filePath"];
              strfileName = System.Configuration.ConfigurationSettings.AppSettings["fileName"];                
             strServiceURL = System.Configuration.ConfigurationSettings.AppSettings["ServiceURL"];
             downloadFiles();
          //  Boolean blnNode1 = ModifyNodeVal("10", "UPLOAD");
       /*
             if (!(String.IsNullOrEmpty(strBuidNum)))
             {
                 downloadFiles();
               //uploadFiles();
             }
        * */
        }

        private static void uploadFiles()
        {
            try
            {
               
                string filetoupload = strfolderPath + "\\" + strfileName;
                          
                // Add code to write in log file
                SkyTapService.FileTransfererImplClient service1 = new SkyTapService.FileTransfererImplClient();
             //   SkyTapLocalService.FileTransfererImplClient service1 = new SkyTapLocalService.FileTransfererImplClient();
                service1.Endpoint.Address = new EndpointAddress(new Uri(strServiceURL));
               
               //  FileStream stream = File.OpenRead(@"D:\\Test\\" + fileName);
                FileStream stream = File.OpenRead(@filetoupload);
                byte[] content = new byte[stream.Length];
                stream.Read(content, 0, (int)stream.Length);

                Logger.writelog("Before web service call");
                service1.uploadwithBuldNum(strBuidNum, strfileName, content);
                stream.Close();
                Logger.writelog("After successful web service call");
                // Now modify xml file with build number

                Boolean blnModiftBuildVal = ModifyNodeVal(strBuidNum, "UPLOAD");
                Logger.writelog("success");
               
            }
            catch (Exception ex)
            {

                Console.WriteLine("error" + ex.Message);
                Logger.writelog("Error - " + ex.Message);
            }

        }


        private static void downloadFiles()
        {
            string strLastBuildNum = "0";
            string strBuild;
            int i = 0;
            try
            {
               
              
                // Create instance of service class
                SkyTapLocalService.FileTransfererImplClient service1 = new SkyTapLocalService.FileTransfererImplClient();
                service1.Endpoint.Address = new EndpointAddress(new Uri(strServiceURL));
                SkyTapLocalService.fileTransferDownload[] lstFL1;
              //  lstFL1= service1.downloadZipFiles("10");
                lstFL1 = service1.downloadZipFiles3();
            
                // Loop through the files returned
                foreach (var m1 in lstFL1)
                {
                    byte[] bt = m1.fileDownload;
                    string strFileName = m1.zipFileName;
                    strBuild = m1.buildNumber;
                   
                    string zipPath = @"d:\TestDownloadStore\" + strFileName;
                    // sameer
                    //    File.WriteAllBytes(zipPath,bt);
                    // start change
                        FileStream fileStream = new FileStream(zipPath, FileMode.Create, FileAccess.ReadWrite);
                        //LoggingService.LogMessage(LoggingService.DEW_INFO, "PublishData Before stream write");
                        fileStream.Write(bt, 0, bt.Length);
                        fileStream.Close();
                       
                    ////////////// end change


                    //using (FileStream fs = File.Create(zipPath))
                    //{
                    //    //Byte[] info = bt;
                    //    // Add some information to the file.
                    //    //fs.Write(info, 0, info.Length);
                    //    fs.Write(bt, 0, bt.Length);
                    //    fs.Close();
                    //}
                   //  string extractPath = "d:\\TestDownloadClient\\extract\\" + strBuild ;
                    string extractPath = @"d:\\TestDownloadClient\\extract";
                    //    ZipFile.CreateFromDirectory(startPath, zipPath, CompressionLevel.Fastest, true);
                    ZipFile.ExtractToDirectory(zipPath, extractPath);
                    Console.WriteLine("success");

                    if (i == 0 || ((Convert.ToInt16(strLastBuildNum) <= Convert.ToInt16(strBuild))))
                    {
                        strLastBuildNum = strBuild;
                    }
                }

                Boolean blnModifyBuild = ModifyNodeVal(strLastBuildNum, "DOWNLOAD");
                Console.WriteLine("success");
               
            }
            catch (Exception ex)
            {

                Console.WriteLine("error" + ex.Message);
                Logger.writelog("Error - " + ex.Message);
                // add code to write in log file

            }

        }


        static Boolean ModifyNodeVal(string strBuild, string strCaller)
        {
            try
            {
                string strBuildConfig = System.Configuration.ConfigurationSettings.AppSettings["buildInfoPath"];
                // comment this
                 
                XmlDocument doc = new XmlDocument();
                doc.Load(strBuildConfig);
                XmlNode Node;

                // get a list of nodes - in this case, I'm selecting all <AID> nodes under
                // the <GroupAIDs> node - change to suit your needs       
                if (strCaller.ToUpper().ToString() == "UPLOAD")
                {
                     Node = doc.SelectSingleNode("/config/lastbuildexecuted");
                }
                else
                {
                     Node = doc.SelectSingleNode("/config/lastbuilddownloaded");

                }
                // Node.Value = "100";
                Node.InnerText = strBuild;
                doc.Save(strBuildConfig);
                return true;
            }
            catch (Exception ex)
            {

                Console.WriteLine("error" + ex.Message);
                Logger.writelog("Error - " + ex.Message);              
                return false;

            }


        }
    }
}
