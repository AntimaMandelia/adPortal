package net.codejava.ws.binary.server;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.ws.WebServiceException;
// newly added
import javax.xml.xpath.XPathConstants;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException; 
import org.omg.SendingContext.RunTime;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipException;

import org.apache.commons.io.IOUtils;





@WebService
public class FileTransfererImpl implements FileTransferer {
	
	// private static final int BUFFER_SIZE = 4096;
	 private List<String> fileList;
	 public String SOURCE_FOLDER = "d:/TestDownload"; 
	 private int intCnt = 0;
	 List<FileTransferDownload> myclass = new ArrayList<FileTransferDownload>() ;
	@WebMethod
	public void uploadwithBuldNum(String BuildNum, String fileName, byte[] imageBytes) throws SAXException, IOException, XPathExpressionException, ParserConfigurationException {
		
		System.out.println ("Inside web service");
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
	 	DocumentBuilder docBuilder;
	 	
		docBuilder = docBuilderFactory.newDocumentBuilder();			
		// TODO Auto-generated catch block
		
		
	 //	Document doc = docBuilder.parse (new File("book.xml"));
	 	File file1 = new File("c:\\serviceconfig\\configuration.xml");
		Document doc = docBuilder.parse(file1);
	 	// normalize text representation
	 
	 	doc.getDocumentElement().normalize ();
	 	System.out.println ("Root element of the doc is " + doc.getDocumentElement().getNodeName());
	 	
	 	XPathFactory xpathFactory = XPathFactory.newInstance();

         // Create XPath object
        XPath xpath = xpathFactory.newXPath();
        XPathExpression expr =
        xpath.compile("/config/uploadfolderpath");
        
        String strFolderName = (String) expr.evaluate(doc, XPathConstants.STRING);
     	System.out.println("read upload folder as : " + strFolderName);	
     	System.out.println("Build number : " + BuildNum);	
     	
 	    String filePath = strFolderName + "/" + fileName ;
 	  //  System.out.println("filepath : " + filePath);	
 	  // Now get path to upload folder
 	    
 	   XPathExpression expr1 =
 		        xpath.compile("/config/buildhistorypath");
 		        
 		        String strBuildHistory = (String) expr1.evaluate(doc, XPathConstants.STRING);
 		     	System.out.println("build history path is : " + strBuildHistory);	
 		     	//System.out.println("Build number : " + BuildNum);	
 		     	
 		 	  
 	    
	 	// end
		// end changes
		 
	//	File file1 = new File("d:\\Test2\\" + fileName);
	
	//	String filePath = "d:\\Test2\\" + fileName;
		// Added to create dynamic folder
		// boolean blFileCreate = new File(strFolderName + "\\" + BuildNum).mkdir();
 		boolean blFileCreate = new File(strBuildHistory + "\\" + BuildNum).mkdir();
	
		// boolean success = (new File("d:/newfolder/Folder1")).mkdirs();
		if (!blFileCreate) {
			System.out.println("directory creation failed");
		}
		System.out.println ("Folder created successfully");
		
		// Below made changes to place file on parent folder not in the build num folder
		// filePath = strFolderName + "\\" + BuildNum + "\\" + fileName ;
		filePath = strFolderName + "\\" + fileName ;
		
		System.out.println("filepath is " + filePath);
		
		try {
			FileOutputStream fos = new FileOutputStream(filePath);
			System.out.println("file stream created");
			BufferedOutputStream outputStream = new BufferedOutputStream(fos);
			outputStream.write(imageBytes);
			System.out.println("file write");
			outputStream.close();
			// Now execute Jenkins
			System.err.println("before jenkins start");
			//String path = "cmd /c start c:\\CICD\execJenkins.bat";
			// Runtime.getRuntime().exec("cmd /c start c:\\CICD\\execJenkins.bat");
			// System.err.println("After Jenkins Start");
			// end
			
		} catch (IOException ex) {
			System.out.println("Received Exception : " + ex.getMessage());
			System.err.println(ex);
			throw new WebServiceException(ex);
		}
		 catch (Exception ex) {
				System.out.println("Received Exception : " + ex.getMessage());
				
		 }
	}
	
	@WebMethod
	public void upload(String fileName, byte[] imageBytes) {
		
		File file1 = new File("d:\\Test2\\" + fileName);
		System.out.println("Received file: " + fileName);
		String filePath = "d:\\Test2\\" + fileName;
		try {
			FileOutputStream fos = new FileOutputStream(filePath);
			System.out.println("file stream created");
			BufferedOutputStream outputStream = new BufferedOutputStream(fos);
			outputStream.write(imageBytes);
			System.out.println("file write");
			outputStream.close();
			
			
			
		} catch (IOException ex) {
			System.out.println("Received Exception : " + ex.getMessage());
			System.err.println(ex);
			throw new WebServiceException(ex);
		}
		 catch (Exception ex) {
				System.out.println("Received Exception : " + ex.getMessage());
				
		 }
	}
	
	@WebMethod
	public byte[] download(String fileName) {
		String filePath = "d:/TestDownload/11/TestResults.html";
		System.out.println("Sending file: " + filePath);
		
		try {
			File file = new File(filePath);
			FileInputStream fis = new FileInputStream(file);
			BufferedInputStream inputStream = new BufferedInputStream(fis);
			byte[] fileBytes = new byte[(int) file.length()];
			inputStream.read(fileBytes);
			inputStream.close();
			
			return fileBytes;
		} catch (IOException ex) {
			System.err.println(ex);
			throw new WebServiceException(ex);
		}		
	}
	
	@WebMethod
	public List<byte[]> downloadFiles(String LastBuildNum) {
		String filePath = "e:/Test/Server/Download/" + LastBuildNum;
		System.out.println("Sending file: " + filePath);
		
		List<byte[]> myBytes = new ArrayList<byte[]>();
		try {
			File file = new File(filePath);
			FileInputStream fis = new FileInputStream(file);
			BufferedInputStream inputStream = new BufferedInputStream(fis);
			byte[] fileBytes = new byte[(int) file.length()];
			inputStream.read(fileBytes);
			inputStream.close();
			myBytes.add(fileBytes);
			return myBytes;
		} catch (IOException ex) {
			System.err.println(ex);
			throw new WebServiceException(ex);
		}		
		
	}
		
		@WebMethod
		public List<FileTransferDownload> downloadZipFiles(String buildNum) {
		//	String filePath = "d:/TestDownload/Test3.zip";
			System.out.println("entered function " );
			//List<FileTransferDownload> myclass = new ArrayList<FileTransferDownload>() ;
			try {
			//////////////////////////////////////////// Start Zip
		     String zipFile = "d:/DownloadFromFolder/11.zip";
			 String sourceDirectory = "d:/DownloadFromFolder/11";
			 
			     //create byte buffer
			 byte[] buffer = new byte[1024];
			 FileOutputStream fout = new FileOutputStream(zipFile);
			// create object of ZipOutputStream from FileOutputStream
			 ZipOutputStream zout = new ZipOutputStream(fout);
			//create File object from directory name
			 System.out.println("before new file");
			 // Start directory from here
			 File dir = new File(sourceDirectory);
			//check to see if this directory exists
			 
			 
			 if(!dir.isDirectory())
			 {
			   System.out.println(sourceDirectory + " is not a directory");			   
			 }
			  else
			 {
				System.out.println("source directory exists");
			    File[] files = dir.listFiles();
			    for(int i=0; i < files.length ; i++)
			    {
			       System.out.println("Adding " + files[i].getName());
			       //create object of FileInputStream for source file
			       FileInputStream fin = new FileInputStream(files[i]);			      
			       zout.putNextEntry(new ZipEntry(files[i].getName()));

			       int length;
			       while((length = fin.read(buffer)) > 0)
			       { 
			    	   	zout.write(buffer, 0, length);
			       }
			      	zout.closeEntry();
			  	   //close the InputStream
			  	   fin.close();
			     }
			   }

			  //close the ZipOutputStream
			  zout.close();
			  System.out.println("Zip file has been created!");
	////////////////////////////////////// end Zip
			
			
			
				// File file = new File(filePath);
			  // Write to stream
			   File file = new File(zipFile);
				FileInputStream fis = new FileInputStream(file);
				BufferedInputStream inputStream = new BufferedInputStream(fis);
				byte[] fileBytes = new byte[(int) file.length()];
				inputStream.read(fileBytes);
				inputStream.close();
				FileTransferDownload cls1 = new FileTransferDownload();
				System.out.println("Before setting output class");
				cls1.setBuildNumber("11");
				cls1.setzipFileName("11.zip");
				cls1.setfileDownload(fileBytes);
				System.out.println("Before setting List");
				// FileTransferDownload[] myclass ;
				// List<FileTransferDownload> myclass = new ArrayList<FileTransferDownload>() ;
				System.out.println("set list class = null");
				myclass.add(cls1);
				System.out.println("added class to list");
				
				// end loop here
				return myclass;
				
				//return fileBytes;
			} catch (IOException ex) {
				System.err.println(ex);
				throw new WebServiceException(ex);
			}		
		
		
		
	}
		
		
		@WebMethod
		public List<FileTransferDownload> downloadZipFiles2() {
		//	String filePath = "d:/TestDownload/Test3.zip";
			System.out.println("entered function " );
			//List<FileTransferDownload> myclass = new ArrayList<FileTransferDownload>() ;
	
			try {
			
			// File dir = new File(GlobalConstants.ELE_DOWNLOADFOLDER);
			//check to see if this directory exists
			 FileConfigRead clsFileRead = new FileConfigRead();
			 String downloadFolderPath = clsFileRead.getConfigValue(GlobalConstants.ELE_DOWNLOADFOLDER);
			 File dir = new File(downloadFolderPath);
			 
			 
			 if(dir.isDirectory())
			 {
				
				 File[] directoryContents = dir.listFiles();
				 for (File file2 : directoryContents) {
					 if (file2.isDirectory()) 
					 {
						// System.out.println("source directory exists");
						 System.out.println("file is directory");
						 File[] files = file2.listFiles();
						 for(int i=0; i < files.length ; i++)
						 {
							 System.out.println("Adding " + files[i].getName());
							 //create object of FileInputStream for source file
							 String zipFile = downloadFolderPath + "/" + files[i].getName() + ".zip";
							 System.out.println("file is " + zipFile);
							 
							 byte[] buffer = new byte[1024];
							 FileOutputStream fout = new FileOutputStream(zipFile);
							 FileInputStream fin = new FileInputStream(files[i]);	
							
							 ZipOutputStream zout = new ZipOutputStream(fout);
							 zout.putNextEntry(new ZipEntry(files[i].getName()));

							 int length;
							 while((length = fin.read(buffer)) > 0)
							 { 
								 zout.write(buffer, 0, length);
							 }
							 zout.closeEntry();
							 //close the InputStream
							 fin.close();
							 zout.close();
							 
							 File fileToDownload = new File(zipFile);
							  FileInputStream fis = new FileInputStream(fileToDownload);
							  BufferedInputStream inputStream = new BufferedInputStream(fis);
							  byte[] fileBytes = new byte[(int) fileToDownload.length()];
							  inputStream.read(fileBytes);
							  inputStream.close();
							 
							 FileTransferDownload cls1 = new FileTransferDownload();
							 System.out.println("Before setting output class");
							 cls1.setBuildNumber(files[i].getName());
							 cls1.setzipFileName(files[i].getName() + ".zip");
							 cls1.setfileDownload(fileBytes);
							 cls1.setdownloadstatus("success");
							 cls1.setexceptiondesc("");
							 myclass.add(cls1);
							 
						 }
					 }
				 }
			  //close the ZipOutputStream
				
			  System.out.println("Zip file has been created!");
			  // Write batch file to clear folder
			} 
			}catch (IOException ex) {
				System.err.println(ex);
				//return myclass;
				//throw new WebServiceException(ex);
				 FileTransferDownload cls1 = new FileTransferDownload();
				 System.out.println("Before setting output class");
				 cls1.setdownloadstatus("Error");
				 cls1.setexceptiondesc(ex.getMessage());
				 myclass.add(cls1);
			}
			return myclass;		
	}
		
	
		/////////////////////// Latest mehod /////////////////////////////////////////////
		@WebMethod
		public List<FileTransferDownload> downloadZipFiles3() {
		//	String filePath = "d:/TestDownload/Test3.zip";
			System.out.println("entered function " );
			List<FileTransferDownload> myclass1 = new ArrayList<FileTransferDownload>() ;
			FileTransferDownload fl1= new FileTransferDownload();
	
			try {
			
			// File dir = new File(GlobalConstants.ELE_DOWNLOADFOLDER);
			//check to see if this directory exists
			 FileConfigRead clsFileRead = new FileConfigRead();
			 String downloadFolderPath = clsFileRead.getConfigValue(GlobalConstants.ELE_DOWNLOADFOLDER);
			// System.out.println("downloadfoldrpath=" + downloadFolderPath );
			 File dir = new File(downloadFolderPath);
			 List<String> fileList2 = null;
			 fileList2 = new ArrayList<String>();
			// String folderName= null;
					 
					 if(dir.isDirectory())
					 {
						
						 File[] directoryContents = dir.listFiles();
						 for (File file2 : directoryContents) {
							 if (file2.isDirectory()) 
							 {
									//zipUtil appZip = new zipUtil();
									String source_folder = downloadFolderPath + "//" + file2.getName();
									 System.out.println("sourceFolder= " + source_folder );
									
									//fileList
									 fileList = new ArrayList<String>();
									 
									//fileList2 = generateFileList(new File(source_folder));
									 generateFileList(new File(source_folder));
									
									 for (String file : fileList)
								      {
										 System.out.println("files read in functiuon3 = " + file );
								      }
								     
									
									
									 System.out.println("After generate list" );
									
									// zipIt(source_folder, file2.getName());
									 fl1 = zipIt(source_folder, file2.getName(), downloadFolderPath);
									 myclass1.add(fl1);
									 System.out.println("After zipit"  );
									 
									 Process pr = Runtime.getRuntime().exec("cmd /c start d:\\scripts\\ArchiveBuild.bat");
									 System.out.println("After archive"  );
							    }
						 }
					 }
			 
			 
			}catch (Exception ex) {
				System.err.println(ex);
				//return myclass;
				//throw new WebServiceException(ex);
				 FileTransferDownload cls1 = new FileTransferDownload();
				 System.out.println("Before setting output class");
				 cls1.setdownloadstatus("Error");
				 cls1.setexceptiondesc(ex.getMessage());
				 
				 myclass1.add(cls1);
			}
			 System.out.println("Before return output");
			 System.out.println("size of myclass1 " +myclass1.size());
			// System.out.println(myclass.size());
			return myclass1;		
	}
		
		/*
		 private void zipDirectory(File folder, String parentFolder, ZipOutputStream zos)
		 {
			 
			 try
			 {
		        for (File file : folder.listFiles()) {
		            if (file.isDirectory()) {
		                zipDirectory(file, parentFolder + "/" + file.getName(), zos);
		                continue;
		            }
		            zos.putNextEntry(new ZipEntry(parentFolder + "/" + file.getName()));
		            BufferedInputStream bis = new BufferedInputStream(
		                    new FileInputStream(file));
		            long bytesRead = 0;
		            byte[] bytesIn = new byte[BUFFER_SIZE];
		            int read = 0;
		            while ((read = bis.read(bytesIn)) != -1) {
		                zos.write(bytesIn, 0, read);
		                bytesRead += read;
		            }
		            zos.closeEntry();
		        }
				}catch (IOException ex) {
					System.err.println(ex);
				}
				}
		 */
		 ///////////////////////// Zip functionality//////////////////////////////////////////////
		// public void zipIt(List<String> fileList3, String sourceFile)
		 public FileTransferDownload zipIt(String sourceFile, String folderName, String downloadFolder)
		 {
		  //  byte[] buffer = new byte[10000];
		    String source = "";
		    FileOutputStream fos = null;
		    ZipOutputStream zos = null;
		    FileTransferDownload cls1 = new FileTransferDownload();
		    try
		    {
		      // try
		     //  {
		         // source = SOURCE_FOLDER.substring(SOURCE_FOLDER.lastIndexOf("\\") + 1, SOURCE_FOLDER.length());
		    	   source = sourceFile;
		      // }
		     // catch (Exception e)
		      //{
		       //  source = SOURCE_FOLDER;
		     // }
		       String zipFile = source + ".zip";
		      fos = new FileOutputStream(zipFile);
		      
		      zos = new ZipOutputStream(fos);

		      System.out.println("Output to Zip : " + zipFile);
		      FileInputStream in = null;
		      byte[] readbuffer;
		   
		   

		      for (String file : fileList)
		      {
		         System.out.println("File Added : " + file);
		         System.out.println("File to be Added : " + source + File.separator + file);
		        // ZipEntry ze = new ZipEntry(source + File.separator + file);
		      //   ZipEntry ze = new ZipEntry(SOURCE_FOLDER + File.separator + file);
		         System.out.println("folder name  : " + folderName);
		         ZipEntry ze = new ZipEntry(folderName + File.separator + file);
		       
		         
		         zos.putNextEntry(ze);
		        
		         try
		         {
		          //  in = new FileInputStream(SOURCE_FOLDER + File.separator + file);
		        	 String fileAdding = source + File.separator + file;
		        	 System.out.println("Now adding file  :" + fileAdding);
		        	  in = new FileInputStream(source + File.separator + file);
		        	//  in = new FileInputStream(SOURCE_FOLDER + File.separator + file);
		            int len;
		            // byte[] buffer = new byte[IOUtils.toByteArray(in).length];
		            byte[] buffer = new byte[1033];
		            
		            System.out.println("after adding buffer  :" + buffer.length);
		            
		            while ((len = in.read(buffer)) > 0)
		            {
		               zos.write(buffer, 0, len);
		            }
		            zos.closeEntry();
		            in.close();
		          //  zos.flush();
		         }
		         finally
		         {
		           // in.close();
		         }
		      } // end of for
		     // in.close();	
		      zos.close();
		      fos.close();
		     // zos.flush();
               
             
		     // zos.closeEntry();
		      System.out.println("Folder successfully compressed");
		    //  readbuffer = Files.readAllBytes(Paths.get("D:\\TestDownload", "2.zip"));
		      // sameer
		      readbuffer = Files.readAllBytes(Paths.get(zipFile));
		      // Now start writing output
		      System.out.println("Zip file name" + zipFile);
		      // added below, comment out later
		      File f = new File(zipFile);
		      ZipInputStream zin = new ZipInputStream(new FileInputStream(zipFile));
		      
		      ZipEntry ze1 = null;
		      while ((ze1 = zin.getNextEntry()) != null) {
		    	 // String path = "D:\\TestDownload\\" + ze1.getName();
		    	  String path = downloadFolder + "\\" + ze1.getName();
		    	 //  String path = "D:\\BuildHistory\\" + ze1.getName();
		    	  System.out.println("path " + path);
                  
		      }
		      File fileToDownload = new File(zipFile);
			  FileInputStream fis = new FileInputStream(fileToDownload);
			  BufferedInputStream inputStream = new BufferedInputStream(fis);
			  byte[] fileBytes = new byte[(int) fileToDownload.length()];
			  inputStream.read(fileBytes);
			  inputStream.close();

		      // return blob, comment out above later
		      //
		      
		      
			 
			 System.out.println("Before setting output class");
			 cls1.setBuildNumber(folderName);
			 cls1.setzipFileName(folderName + ".zip");
     		 cls1.setfileDownload(fileBytes);
			 //cls1.setfileDownload(Files.readAllBytes(Paths.get(zipFile)));
			// cls1.setfileDownload(readbuffer);
			 
			 cls1.setdownloadstatus("success");
			 cls1.setexceptiondesc("");
			 myclass.add(cls1);
			 intCnt = intCnt + 1;
			 System.out.println("executed " + intCnt);
			 System.out.println("Build Number " + cls1.getBuildNumber());
			 System.out.println("zip file name " + cls1.getzipFileName());
			// System.out.println("Buffer length : " + readbuffer.length);

		   }
		   catch (IOException ex)
		   {
		      ex.printStackTrace();
		   }
		   return cls1;
		 }
		

		// public List<String> generateFileList(File node)
		 public void generateFileList(File node)
		 {

		   // add file only
			 System.out.println("Inside generate file list");
		  // List<String> fileList1 ;
		  // fileList1 = new ArrayList<String>();
		   
		   if (node.isFile())
		   {
			//   System.out.println("Node is file");
			   // fileList1.add(generateZipEntry(node.toString()));
			//   System.out.println("file " + node.getAbsoluteFile().toString());
			  // System.out.println("parent file path string " + node.getParent());
			   System.out.println("parent file path absolute " + node.getParentFile().getAbsolutePath().toString());
			   
			   fileList.add(generateZipEntry(node.getAbsoluteFile().toString(), node.getParentFile().getAbsolutePath().toString()));
			 //  System.out.println("added file " + node.getAbsoluteFile().toString());

		   }

		   if (node.isDirectory())
		   {
		      String[] subNote = node.list();
		      System.out.println("Node is directory" + subNote);
		      for (String filename : subNote)
		      {
		        //  generateFileList(new File(node, filename));
		    	  generateFileList(new File(node + "/" + filename));
		      }
		   }
		   /*
		   for (String file : fileList)
		      {
				 System.out.println("files in generate list =" + file );
		      }
		      */
		   
		 //  return fileList1;
		 }

		 private String generateZipEntry(String file, String parentFile)
		 {
			// return file;
			 
			// System.out.println("after substring" + file.substring(parentFile.length() + 1, file.length() - parentFile.length()));
			// System.out.println(file.length());
			// System.out.println(parentFile.length());
			 
			 int fileLength = file.length() - parentFile.length();
			// System.out.println(fileLength);
			 
			 String strSub = file.substring(parentFile.length() + 1, file.length());
			// System.out.println("final string " + strSub);
			 return strSub;
			 
			//return file.substring(file.length() + 1, parentFile.length());
		   // return file.substring(SOURCE_FOLDER.length() + 1, file.length());
		 }

			///////////////////////////////////////////////////////////////////////////////////
		 
		    }


		
