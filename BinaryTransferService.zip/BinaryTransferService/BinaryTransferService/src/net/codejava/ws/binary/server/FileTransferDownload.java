package net.codejava.ws.binary.server;

public class FileTransferDownload {
	
	private String BuildNumber;
    private String zipFileName;
    private byte[] fileDownload;
    private String downloadstatus;
    private String exceptiondesc;
    
    public String getBuildNumber() {
        return BuildNumber;
    }
    public void setBuildNumber(String strBuildNumber) {
        this.BuildNumber = strBuildNumber;
    }
    
    public String getzipFileName() {
        return zipFileName;
    }
    public void setzipFileName(String strzipFileName) {
        this.zipFileName = strzipFileName;
    }
    
    public byte[] getfileDownload() {
        return fileDownload;
    }
    public void setfileDownload(byte[] strfileDownload) {
        this.fileDownload = strfileDownload;
    }
    
    public String getdownloadstatus() {
        return downloadstatus;
    }
    public void setdownloadstatus(String strstatus) {
        this.downloadstatus = strstatus;
    }
    
    public String getexceptiondesc() {
        return exceptiondesc;
    }
    public void setexceptiondesc(String strexception) {
        this.exceptiondesc = strexception;
    }
    

}
