package net.codejava.ws.binary.server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.ws.WebServiceException;
// newly added
import javax.xml.xpath.XPathConstants;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException; 
import org.omg.SendingContext.RunTime;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;




public class FileConfigRead {
	
	public String getConfigValue(String configKey)
	{
		String strConfigVal = "";
		try
		{
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder;
	 	
			docBuilder = docBuilderFactory.newDocumentBuilder();
		
		// TODO Auto-generated catch block
		
		
			//	Document doc = docBuilder.parse (new File("book.xml"));
			File file1 = new File(GlobalConstants.FILE_CONFIG);
			Document doc = docBuilder.parse(file1);
			// normalize text representation
	 
			doc.getDocumentElement().normalize ();
			System.out.println ("Root element of the doc is " + doc.getDocumentElement().getNodeName());
	 	
			XPathFactory xpathFactory = XPathFactory.newInstance();

			// Create XPath object
			XPath xpath = xpathFactory.newXPath();
			XPathExpression expr =
			xpath.compile(configKey);
        
			strConfigVal = (String) expr.evaluate(doc, XPathConstants.STRING);
		//	return strConfigVal;
 	    
		}
 	    catch(Exception ex)
 	    {
 	    	System.err.println(ex);
			throw new WebServiceException(ex);
 	    }
		return strConfigVal;
		
	}
	
	
	
	

}
