package net.codejava.ws.binary.server;

public interface GlobalConstants {

	
	String RETURN_VALUE_SUCCESS = "success";
	String RETURN_VALUE_FAILURE = "failure";
	String FILE_CONFIG = "c:\\serviceconfig\\configuration.xml";
	String ELE_UPLOADFOLDER = "/config/uploadfolderpath";
	// String ELE_DOWNLOADFOLDER = "/config/downloadfolderpath";
	String ELE_DOWNLOADFOLDER = "/config/buildhistorypath";
	
	
	String BOOK_DETAIL_ACTION = "book_detail";
	String MENU_ACTION = "menu";
	String MY_INFO_ACTION = "myInfo";
	String ISSUE_BOOK_ACTION = "book_issue";
	String RETURN_BOOK_ACTION = "book_return";
	String ERROR_PAGE = "error";
	String UPDATE_BOOK_DATABASE = "bookDB_updated_Thanks";
	String BOOK_SEARCH ="book_search";
	String RETURN_RECEIPT = "receipt";
	
	
}
