package net.codejava.ws.binary.client;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.w3c.dom.*; 

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.ws.soap.MTOMFeature;
import javax.xml.xpath.XPathConstants;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException; 
import org.w3c.dom.NodeList;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;




import net.codejava.ws.binary.server.FileTransferer;

public class WebServiceClient {
	 public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
	        // connects to the web service
		 
		 // XML value
		 	DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		 	DocumentBuilder docBuilder;
			
			docBuilder = docBuilderFactory.newDocumentBuilder();			
			// TODO Auto-generated catch block
		
		 //	Document doc = docBuilder.parse (new File("book.xml"));
		 	File file1 = new File("c:\\serviceconfig\\configuration.xml");
			Document doc = docBuilder.parse(file1);
		 	// normalize text representation
		 
		 	doc.getDocumentElement ().normalize ();
		 	System.out.println ("Root element of the doc is " + doc.getDocumentElement().getNodeName());
		 	
		 	
 ///////////////////////////////////////////////////////////////////////////////
		 /*	NodeList listOfPersons = doc.getElementsByTagName("person");
		 	int totalPersons = listOfPersons.getLength();
		 	System.out.println("Total no of people : " + totalPersons);		
		 	*/
		 	 XPathFactory xpathFactory = XPathFactory.newInstance();

            // Create XPath object
            XPath xpath = xpathFactory.newXPath();
            XPathExpression expr =
            xpath.compile("/config/uploadfolderpath");
           
            String strFolderName = (String) expr.evaluate(doc, XPathConstants.STRING);
        	System.out.println("name : " + strFolderName);	
        	
        	XPathExpression expr1 =
    	    xpath.compile("/config/filename");

    	    String strFileName = (String) expr1.evaluate(doc, XPathConstants.STRING);
    	    String filePath = strFolderName + "/" + "strFileName";
    	    System.out.println("filepath : " + filePath);	
    	    System.out.println("exit ");	
    	    File file = new File(filePath);	         
	        System.out.println("file uploaded succssfully");
	        FileOutputStream fos = new FileOutputStream(filePath);
            BufferedOutputStream outputStream = new BufferedOutputStream(fos);
            System.out.println("after write stream");
            outputStream.close();
      /*
		 // End read XML field value
		 
	        FileTransfererImplService client = new FileTransfererImplService();
	       // FileTransfererImpl service = client.getFileTransfererImplPort();
	        FileTransfererImpl service = client.getFileTransfererImplPort(new MTOMFeature());
	       
	        	         
	 
	      //  String fileName = "abc.txt";
	      //   String filePath = "d:\\Test\\" + fileName;
	        File file = new File(filePath);	         
	        System.out.println("File Path= " + filePath);
	        // uploads a file
	        try {
	            FileInputStream fis = new FileInputStream(file);
	            BufferedInputStream inputStream = new BufferedInputStream(fis);
	            byte[] imageBytes = new byte[(int) file.length()];
	            
	            inputStream.read(imageBytes);	             
	           service.upload(file.getName(), imageBytes);	 
	           
	            
	            inputStream.close();
	            System.out.println("File uploaded: " + filePath);
	        } catch (IOException ex) {
	            System.err.println(ex);
	        }    
	       
	        */
	         /*
	        // downloads another file
	        fileName = "camera.png";
	        filePath = "E:/Test/Client/Download/" + fileName;
	        byte[] fileBytes = service.download(fileName);
	         
	        try {
	            FileOutputStream fos = new FileOutputStream(filePath);
	            BufferedOutputStream outputStream = new BufferedOutputStream(fos);
	            outputStream.write(fileBytes);
	            outputStream.close();
	             
	            System.out.println("File downloaded: " + filePath);
	        } catch (IOException ex) {
	            System.err.println(ex);
	        }
	        */
	    }


}
