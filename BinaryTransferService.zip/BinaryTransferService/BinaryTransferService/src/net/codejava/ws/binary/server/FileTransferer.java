package net.codejava.ws.binary.server;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.ws.soap.MTOM;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.SAXException;

@WebService
@MTOM(enabled = true, threshold = 10240)
public interface FileTransferer {
	
	@WebMethod
	public void upload(String fileName, byte[] imageBytes) ;
	
	@WebMethod
	public void uploadwithBuldNum(String BuildNum, String fileName, byte[] imageBytes) throws SAXException, IOException, XPathExpressionException, ParserConfigurationException;
	
	@WebMethod
	public byte[] download(String fileName);	
	
	
	
	@WebMethod
	public List<byte[]> downloadFiles(String LastBuildNum);
	
	@WebMethod
	public List<FileTransferDownload> downloadZipFiles(String LastBuildNum);
	
	@WebMethod
	public List<FileTransferDownload> downloadZipFiles2();
	
	@WebMethod
	public List<FileTransferDownload> downloadZipFiles3();
	
}
