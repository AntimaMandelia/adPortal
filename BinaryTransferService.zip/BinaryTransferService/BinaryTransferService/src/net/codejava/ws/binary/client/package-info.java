@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.binary.ws.codejava.net/")
package net.codejava.ws.binary.client;
